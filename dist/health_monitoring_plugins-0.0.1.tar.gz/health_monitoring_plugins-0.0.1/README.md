## health monitoring plugins project:
---

This is the main readme file for the health montiroing plugins project. In this project we pubish all our plugins we write for icinga.
In every single plugin folder, you will find an own readme file, that describes the details of the plugin.

Additionally we will provide an python setup package, that can be downloaded.
All plugins are released under the GPLv2.